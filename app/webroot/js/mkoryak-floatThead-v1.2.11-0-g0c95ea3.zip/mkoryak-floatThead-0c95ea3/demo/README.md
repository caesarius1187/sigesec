Demos were moved into the gh-pages branch.

https://github.com/mkoryak/floatThead/tree/gh-pages

Go there for instruction on how to download them
